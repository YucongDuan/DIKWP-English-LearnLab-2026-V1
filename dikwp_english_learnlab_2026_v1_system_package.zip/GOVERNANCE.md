# Governance and Safety Boundary

## Human responsibility
Teachers, students, parents, and peers remain responsible for learning decisions and assessment. AI can assist with explanation, practice, roleplay, feedback, and evidence organization, but must not replace authentic student output.

## Prohibited uses
- automatically grade high-stakes exams or determine admissions/placement
- ghostwrite homework, essays, speeches, or research reports
- fabricate oral recordings, citations, or learning evidence
- upload private student data or exam-confidential materials
- use AI-detection tools as the sole evidence of misconduct
- rank students secretly or form permanent learner labels

## Required safeguards
- AI Use Log
- original drafts and revisions
- oral reproduction or human questioning for important outputs
- student-visible evidence ledger
- error recovery plan
- teacher or peer review for high-stakes work

## Kill conditions
Stop or downgrade the workflow if AI output is submitted as student work, sensitive data are uploaded, the learner cannot reproduce key language without AI, or the learning purpose changes materially.
