#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r"\brequests\.","network requests"),(r"\burllib\.request","URL access"),(r"\bsocket\.","raw socket"),(r"\beval\(","eval"),(r"\bexec\(","exec"),(r"\bos\.system","shell")]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
        txt=p.read_text(encoding='utf-8',errors='ignore')
        for pattern,meaning in PATTERNS:
            if re.search(pattern,txt,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
    result={'package':'DIKWP English LearnLab 2026 V1','network_or_dynamic_execution_detected':bool(findings),'findings':findings,'note':'No external model calls, LMS writeback, or automated grading adapter is included.'}
    (ROOT/'static_boundary_audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
