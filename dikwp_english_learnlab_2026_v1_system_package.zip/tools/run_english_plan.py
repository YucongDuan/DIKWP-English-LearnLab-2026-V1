#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime,timezone

def main():
    p=argparse.ArgumentParser();p.add_argument('learner',type=Path);p.add_argument('--out',type=Path,default=Path('outputs'));args=p.parse_args()
    learner=json.loads(args.learner.read_text(encoding='utf-8'))
    report={
        'version':'DIKWP English LearnLab 2026 V1 CLI',
        'generated_at':datetime.now(timezone.utc).isoformat(),
        'learner':learner,
        'recommended_weekly_loop':['vocabulary retrieval','listening dictation','graded reading','three-draft writing','speaking recording','error review','AI use log'],
        'boundaries':{'automatic_high_stakes_grading':False,'ghostwriting':False,'human_teacher_review_required':True}
    }
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/f"{learner.get('learner_id','learner')}_english_learning_passport.json"
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP English LearnLab 2026 V1')
    print('Output:',target)
    print('Boundary: no ghostwriting or automated high-stakes grading.')
if __name__=='__main__': main()
