# 30-Day Pilot Plan

## Week 1: Diagnosis and boundaries
- choose one class or one learner group
- define purpose: school exam, speaking, CET, Gaokao, workplace, IELTS/TOEFL
- run baseline tasks in vocabulary, listening, reading, writing, and speaking
- define AI rules and evidence fields

## Week 2: Input and retrieval
- run vocabulary retrieval cycles
- complete short listening dictation and shadowing
- complete graded reading with retelling
- start Error Ledger

## Week 3: Output and feedback
- write one three-draft text
- complete two speaking recordings and one AI roleplay with human retelling
- close selected errors through retrieval and transfer

## Week 4: Authentic task and review
- complete one mission project
- teacher/peer review evidence
- generate English Learning Passport
- revise next 60-day plan

## Acceptance criteria
- no ghostwriting
- AI use logged
- at least five evidence items
- at least one original draft and revision note
- at least one oral or written output reproduced without AI
- learner can explain key residuals and next actions
