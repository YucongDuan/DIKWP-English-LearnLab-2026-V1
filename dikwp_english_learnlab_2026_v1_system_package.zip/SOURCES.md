# Sources

- Ministry of Education of China, Compulsory Education English Curriculum Standards (2022 edition).
- Ministry of Education of China, China Standards of English (CSE), 2018.
- General Senior High School English Curriculum Standards (2017 edition, 2020 revision).
- Council of Europe, CEFR Companion Volume, 2020.
- Freeman-style active learning evidence is used in other DIKWP education prototypes; this English system specifically uses second language research on spaced practice, retrieval, extensive reading, and AI-assisted ELT.
- UNESCO, Guidance for Generative AI in Education and Research, 2023.
- British Council, AI in English language teaching reports and 2024 ELT trends.

All ratios, maturity thresholds, and synthetic scores are heuristic design aids, not national standards or official exam score predictions.
